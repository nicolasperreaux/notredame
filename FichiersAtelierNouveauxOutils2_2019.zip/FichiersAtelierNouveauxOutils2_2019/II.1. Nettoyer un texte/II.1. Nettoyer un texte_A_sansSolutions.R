######################################################################################################
# Script �crit pour l'atelier "Du parchemin � la fouille de donn�es. Nouveaux outils pour la cr�ation, 
#      la formalisation et l'analyse des corpus m�di�vaux", Paris, 28-30 octobre 2019
# Paul Bertrand, �tienne Cuvelier, S�bastien de Valeriola, Nicolas Perreaux, Nicolas Ruffini-Ronzani
#
######################################################################################################
# II.1. Nettoyer un texte A
######################################################################################################

rm(list=ls())
setwd("D:\\DigitalHumanities\\Evenements\\2019.10.28_Atelier Nouveaux Outils 2\\Livrables\\II.1. Nettoyer un texte")

library(stringr)
  

# 0. Chargement des donnees ----
volume1 = readLines("data/ND_volume1_etat1.txt",encoding = "UTF-8")

# verification que le chargement s'est bien deroule 
volume1[1]
length(volume1)



# 1. Fonctions R � utiliser ----

# exercice :  
str_subset(string = volume1, pattern = 'mense Januario')



# 2. Sequences d'echappement ----

# exemples : 
text = c('x	y','xxy','xysfdres','xy$')
str_subset(string = text, pattern = '\t')
str_subset(string = text, pattern = '$')
str_subset(string = text, pattern = '\\$')
  
# exercice :  



# 3. Operateurs ----

# exemples : 
text = c('xy','xwy','xzeedy','xy21','xy001','mnop')
str_subset(string = text, pattern = 'x.')
str_subset(string = text, pattern = 'x[^y]')
str_subset(string = text, pattern = 'x[w-y]')
str_subset(string = text, pattern = 'xy[2-9]')
str_subset(string = text, pattern = 'xy|mn')

lignesMotif = str_subset(string = volume1, pattern = '100[0-9]')
str_extract(string = lignesMotif, pattern = '100[0-9]')

# exercice : 



# 4. Quantificateurs ----

# exemples : 
text = c('xy','x-y','x--y','x---y','x----y')
str_subset(string = text, pattern = 'x-y')
str_subset(string = text, pattern = 'x-*y')
str_subset(string = text, pattern = 'x-+y')
str_subset(string = text, pattern = 'x-?y')
str_subset(string = text, pattern = 'x-{2}y')
str_subset(string = text, pattern = 'x-{2,}y')
str_subset(string = text, pattern = 'x-{2,3}y')

as.numeric(as.roman("MCCLIV"))

# exercice :  



# 5. Comportement des quantificateurs ----

# exemple :  
text = c('xyxyy___xyy')
str_extract(string = text, pattern = '.*y')
str_extract(string = text, pattern = '.*?y')

text = c('<tag>Some text</tag>')
str_replace_all(string = text, pattern = '<.+>',replacement = "")
str_replace_all(string = text, pattern = '<.+?>',replacement = "")

# exercice : 



# 6. Classes de caracteres ----

# exemple : 
text = c('xy','xwy','xzeedy','xy21','xy001','mnop')
str_subset(string = text, pattern = '[[:digit:]]')

# exercice : 



# 7. Position au sein de la chaine ----

# exemple : 
text = c('xy','xwy','xzeedx','yxxx210','xy001','mnopx','eds xdes')
str_subset(string = text, pattern = '^x')
str_subset(string = text, pattern = 'x$')
str_subset(string = text, pattern = '\\bx')
str_subset(string = text, pattern = '\\<x')

# exercice : 



# 8. Retro-references ----

# exemple : 
text = c('The numbers are aa01214 and bb007')
str_replace(string = text, pattern = '.*[a-z]{2}([0-9]{3,}).*\\s[a-z]{2}([0-9]{3,})',replacement = "\\1 & \\2")
str_replace(string = text, pattern = '.*[a-z]{2}(?:[0-9]{3,}).*\\s[a-z]{2}([0-9]{3,})',replacement = "\\1")

# exercice : 






